<?php

// koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "php");

// query data dari database

function query($query)
{
    global $koneksi;
    $hasil = mysqli_query($koneksi, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($hasil)) {
        $rows[] = $row;
    }
    return $rows;
}

function ubah($data)
{
    global $koneksi;
    $id = $data["id"];
    $nama = htmlspecialchars($data["nama"]);
    $sekolah = htmlspecialchars($data["sekolah"]);

    $query = "UPDATE tb_anggota SET nama = '$nama', sekolah = '$sekolah' WHERE id = $id ";

    mysqli_query($koneksi, $query);

    return mysqli_affected_rows($koneksi);
}

function hapus($id)
{
    global $koneksi;
    mysqli_query($koneksi, "DELETE FROM tb_anggota WHERE id = $id");
    return mysqli_affected_rows($koneksi);
}

function tambah($data)
{
    global $koneksi;
    $nama = htmlspecialchars($data["nama"]);
    $sekolah = htmlspecialchars($data["sekolah"]);

    $query = "INSERT INTO tb_anggota VALUES('', '$nama', '$sekolah')";
    mysqli_query($koneksi, $query);
    return mysqli_affected_rows($koneksi);
}
