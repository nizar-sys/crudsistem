<?php

// panggil file function
require_once 'functions.php';

// ambil id dari url
$id = $_GET["id"];

// fungsi saat tombol hapus di click
if (hapus($id) > 0) {
    echo "
    <script>
        alert('Data berhasil dihapus!');
        document.location.href = 'index.php';
    </script>
";
} else {
    echo "
    <script>
        alert('Data gagal dihapus!');
        document.location.href = 'index.php';
    </script>
";
}
